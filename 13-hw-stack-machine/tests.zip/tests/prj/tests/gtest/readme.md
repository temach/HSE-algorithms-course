Google test

The structure of the directory should correspond to a structure of VS (CMake/QtCreator) projects 